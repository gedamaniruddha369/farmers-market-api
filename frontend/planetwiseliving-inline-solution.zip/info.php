<?php
// Display PHP info
phpinfo();
?> 